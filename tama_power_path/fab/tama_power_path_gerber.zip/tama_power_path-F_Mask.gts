%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-16T11:42:33+08:00*%
%TF.ProjectId,tama_power_path,74616d61-5f70-46f7-9765-725f70617468,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-16 11:42:33*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.200000X-0.200000X-0.275000X0.200000X-0.275000X0.200000X0.275000X-0.200000X0.275000X0*%
%ADD11C,1.400000*%
%ADD12RoundRect,0.250000X-1.000000X-0.650000X1.000000X-0.650000X1.000000X0.650000X-1.000000X0.650000X0*%
%ADD13RoundRect,0.150000X0.587500X0.150000X-0.587500X0.150000X-0.587500X-0.150000X0.587500X-0.150000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,R1*%
X8175000Y-8600000D03*
X9825000Y-8600000D03*
%TD*%
D11*
%TO.C,J4*%
X12500000Y-8600000D03*
%TD*%
%TO.C,J3*%
X1500000Y-2500000D03*
%TD*%
%TO.C,J1*%
X12500000Y-2500000D03*
%TD*%
D12*
%TO.C,D1*%
X5000000Y-2500000D03*
X9000000Y-2500000D03*
%TD*%
D11*
%TO.C,J2*%
X1500000Y-6600000D03*
%TD*%
D13*
%TO.C,Q1*%
X5737500Y-7550000D03*
X5737500Y-5650000D03*
X3862500Y-6600000D03*
%TD*%
M02*
